use std::io;
use std::env;
use std::error::Error;
use std::fs::File;
use std::fmt;
use csv::ReaderBuilder;
use argon2::password_hash::{PasswordHash, PasswordVerifier};
use argon2::Argon2;
use std::collections::HashMap;

#[derive(Debug)]
struct PasswordVerificationError {
    source: argon2::password_hash::Error,
}

impl fmt::Display for PasswordVerificationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Password verification failed: {}", self.source)
    }
}

impl Error for PasswordVerificationError {}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 2 {
        eprintln!("Usage: cargo run db.csv");
        return Err("Incorrect number of arguments provided. Please provide the filename as an argument.".into());
    }

    let filename = &args[1];
    if !File::open(filename).is_ok() {
        eprintln!("Error! Password database not found!");
        return Err("Password database not found!".into());
    }

    let mut rdr = ReaderBuilder::new().has_headers(false).from_path(filename)?;
    let mut user_data: HashMap<String, String> = HashMap::new();
    for result in rdr.deserialize() {
        let record: (String, String) = result?;
        user_data.insert(record.0, record.1.to_string());
    }

    println!("Enter username:");
    let username = read_input()?;
    println!("Enter password:");
    let password = read_input()?;

    if let Some(hash) = user_data.get(&username) {
        if verify_password(hash, &password)? {
            println!("Access granted!");
        } else {
            println!("Error! Access denied!");
        }
    } else {
        println!("Error! Access denied!");
    }

    Ok(())
}

fn read_input() -> Result<String, Box<dyn Error>> {
    let mut input = String::new();
    io::stdin().read_line(&mut input)?;
    Ok(input.trim().to_string())
}

fn verify_password(hash: &str, password: &str) -> Result<bool, Box<dyn Error>> {
    let parsed_hash = PasswordHash::new(hash).map_err(|e| {
        eprintln!("Error parsing hash: {}", e);
        Box::new(PasswordVerificationError { source: e }) as Box<dyn Error>
    })?;
    let verifier = Argon2::default();
    match verifier.verify_password(password.as_bytes(), &parsed_hash) {
        Ok(_) => Ok(true),
        Err(_) => {
            eprintln!("Error! Access denied!");
            Ok(false)
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const TEST_DB_CONTENT: &str = "user1,$argon2id$v=19$m=4096,t=3,p=1$3jJ5EuY8wwt3GxBYz3qMfQ$y8tC04e6cfqWJ9LhW8jFuG1aCUwzNt6zDOtAq6kP6bQ\nuser2,$argon2id$v=19$m=4096,t=3,p=1$3jJ5EuY8wwt3GxBYz3qMfQ$y8tC04e6cfqWJ9LhW8jFuG1aCUwzNt6zDOtAq6kP6bQ";

    #[test]
    fn test_incorrect_password() {
        assert!(login("test_db.csv", "user1", "wrong_password").is_err());
    }

    #[test]
    fn test_missing_database() {
        assert!(login("nonexistent_db.csv", "user1", "password").is_err());
    }
}

fn login(db_filename: &str, username: &str, password: &str) -> Result<(), Box<dyn Error>> {
    let filename = db_filename;
    if !File::open(filename).is_ok() {
        return Err("Password database not found!".into());
    }

    let mut rdr = ReaderBuilder::new().has_headers(false).from_path(filename)?;
    let mut user_data: HashMap<String, String> = HashMap::new();
    for result in rdr.deserialize() {
        let record: (String, String) = result?;
        user_data.insert(record.0, record.1.to_string());
    }

    if let Some(hash) = user_data.get(username) {
        if verify_password(hash, password)? {
            return Ok(());
        }
    }

    Err("Incorrect username or password!".into())
}

